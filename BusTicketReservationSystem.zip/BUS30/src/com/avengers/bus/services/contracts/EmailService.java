package com.avengers.bus.services.contracts;

public interface EmailService {
	// It will send email to the specified email address..
	public int sendmail(String to_mail, String purpose);

}
