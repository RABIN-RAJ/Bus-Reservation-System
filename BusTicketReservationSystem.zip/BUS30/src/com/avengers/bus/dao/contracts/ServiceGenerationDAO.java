package com.avengers.bus.dao.contracts;

public interface ServiceGenerationDAO {
	// It will generate the services automatically
	public void callAutoGenerateServicesProcedure();

}
